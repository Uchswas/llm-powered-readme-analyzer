---
license: unknown
---
awq quant made with [lmdeploy](https://github.com/InternLM/lmdeploy) v0.4.2:
```
lmdeploy lite auto_awq sophosympatheia/Midnight-Miqu-70B-v1.5 --work-dir Midnight-Miqu-70B-v1.5-4bit
```