---
license: creativeml-openrail-m
tags:
- text-to-image
- stable-diffusion
- lora
- diffusers
base_model: stabilityai/stable-diffusion-xl-base-1.0
instance_prompt: Stickers, sticker
widget:
  - text: Stickers, sticker
---
# Stickers.Redmond
![row01](00000-3383490575.png)

Stickers.Redmond is here!

Introducing Stickers.Redmond, the ultimate LORA for creating Stickers images!

I'm grateful for the GPU time from Redmond.AI that allowed me to make this LORA! If you need GPU, then you need the great services from Redmond.AI.

It is based on SD XL 1.0 and fine-tuned on a large dataset.

The LORA has a high capacity to generate Coloring Book Images!

The tag for the model: Stickers, Sticker

I really hope you like the LORA and use it.

If you like the model and think it's worth it, you can make a donation to my Patreon or Ko-fi.

Patreon:

https://www.patreon.com/user?u=81570187

Ko-fi:https://ko-fi.com/artificialguybr

BuyMeACoffe:https://www.buymeacoffee.com/jvkape

Follow me in my twitter to know before all about new models:

https://twitter.com/artificialguybr/