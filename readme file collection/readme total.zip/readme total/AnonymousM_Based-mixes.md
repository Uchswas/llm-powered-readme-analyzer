---
license: cc-by-4.0
language:
- en
tags:
- anime
- art
---
A model I made anonymously at the start using a Vtuber finetuned model created anonymously along with WarriorMama777's AbyssOrangeMix2 mixes as a starting point for my mixes
https://huggingface.co/WarriorMama777/OrangeMixs#abyssorangemix2_hard-aom2h

the reasons being? Well I like Vtubers and both models had great NSFW capabilites along with me liking the very simple anime look the final epoch for HLL3 has. Luckily it seems like version 4 
of the users' model has been uploaded here so I will be providing the link 
https://huggingface.co/CluelessC/hll-test/tree/main


and this is the link as well for the 3rd revision of the model I was using up until Based65-final-mix
https://huggingface.co/grugger/chubas/resolve/main/models/mirrors/hll3vtubers-last-pruned.safetensors

Aside from that there's nothing really crazy I have to say about this model that I didn't say on the Civitai upload, which if you want to keep up with what I'm doing I have 
a Linktree sharing all my social media platforms
https://linktr.ee/anonymousm

You can use the model however you like just remember to credit me and refer to my CC-License
https://mega.nz/file/qExmQBQA#9eyI78TMEJu8V4c84UWitrlDAjyqxrxSVc1D5ktb87k

If you plan on using any of the based mixes for your own merge... go ahead, just a word of advice the nature of the Based mixes, which I only included the first mix in here 
for the sake of archiving it's not that very good at anything compared to the other Based-mixes, V3 up until 65-Final-Mix are all good but using it as a merge there's 
something I noticed with model merges, in my recipes especially for Based66-mix, the next entry I am working on, had trouble with getting full accurate details of trained
LORAs like Based65 final mix, the reason for this is due to if more than 2 merged models that contain a fintuned model that isn't NAI is in the mix it can conflict heavily
with LORA outputs. Based64 and 65-proto-mix do not suffer from this due to my knowledge on 2 finetuned models being included with the recipe I used. I plan on researching
more deeply into how models I use in future based mixes are created to avoid this issue. Yet yes with all of that said if you plan on merging my mixes with your own remember
to credit me or whatever, you can do whatever you want with the merge but just remember 65 final mix may conflict with LORAs along with whatever merged finetuned model you
put into your recipe.

*New model added Based66*
Both versions have been uploaded to here with the main goal of making sure LORA compatibility is at its best while ensuring that I use HLL4, the 4th version of the Hololive 
Vtuber finetuned model, Version 1 is the first attempt that suffers from anatomy issues, Version 2 achieves the desire for LORA compatibility but adds the need for stronger 
weights on prompts to create your desired output, V3 will be worked on to fix these issues in the near future.