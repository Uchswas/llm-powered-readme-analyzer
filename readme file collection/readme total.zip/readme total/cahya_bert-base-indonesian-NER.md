---
license: mit
language:
- id
pipeline_tag: token-classification
---