---
license: creativeml-openrail-m
tags:
- text-to-image
- stable-diffusion
- lora
- diffusers
base_model: stabilityai/stable-diffusion-xl-base-1.0
instance_prompt: ColoringBookAF, Coloring Book
widget:
  - text: ColoringBookAF, Coloring Book
---
# ColoringBook.Redmond V2
![row01](00493-1759595235.png)

ColoringBook.Redmond is here!

TEST ALL MY LORA HERE|: https://huggingface.co/spaces/artificialguybr/artificialguybr-demo-lora/

Introducing ColoringBook.Redmond, the ultimate LORA for creating Coloring Book images!

I'm grateful for the GPU time from Redmond.AI that allowed me to make this LORA! If you need GPU, then you need the great services from Redmond.AI.

It is based on SD XL 1.0 and fine-tuned on a large dataset.

The LORA has a high capacity to generate Coloring Book Images!

The tag for the model:ColoringBookAF, Coloring Book

I really hope you like the LORA and use it.

If you like the model and think it's worth it, you can make a donation to my Patreon or Ko-fi.

Patreon:

https://www.patreon.com/user?u=81570187

Ko-fi:https://ko-fi.com/artificialguybr

BuyMeACoffe:https://www.buymeacoffee.com/jvkape

Follow me in my twitter to know before all about new models:

https://twitter.com/artificialguybr/