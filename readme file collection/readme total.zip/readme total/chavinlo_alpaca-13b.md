# Alpaca-native 13B

NO LORA