---
license: apache-2.0
---

This is a tiny, dummy version of [Jamba](https://huggingface.co/ai21labs/Jamba-v0.1), used for debugging and experimentation over the Jamba architecture.

It has 128M parameters (instead of 52B), **and is initialized with random weights and did not undergo any training.**
