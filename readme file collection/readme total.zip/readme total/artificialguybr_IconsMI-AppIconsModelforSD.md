---
license: creativeml-openrail-m
tags:
  - text-to-image
---

To use it you have to use the word ''IconsMi'' in the prompt.

From my tests the images look better with this prompt:

highly detailed, trending on artstation, ios icon app, IconsMi

For negative prompts I got better results when I used: out of frame, duplicate, watermark, signature, text, ugly, sketch, deformed, mutated, blurry, mutilated, ugly sketch

I recommend you to instead describe the style of app you want, e.g. news app, music app, sports app. Describe what you want in the image. For example, ''a reporter microphone''. The results are better. SD doesn't understand these abstractions yet.

The Model was made in 7200 Steps with models saved every 700 steps after the 2000 steps.

In my tests the 2k model was the one that got the most creativity and had the most variety of themes in the generation.

The 5500 model was the one that had the best image quality, but did not know how to abstract and be creative.

I included both models for you to test. Both use the same prompt ''IconsMi

You can help me on mine:

Patreon:https://www.patreon.com/user?u=81570187
Ko-Fi:https://ko-fi.com/jvkape
buy me a coffe:https://www.buymeacoffee.com/JVKAPE

All money will go towards the creation of new models.
