---
tags:
- text-to-image
- stable-diffusion
- lora
- diffusers
- template:sd-lora
widget:
- text: a boy in a sailor suit frowning
  output:
    url: images/BW_e000014_02_20240610214209.jpeg
- text: a toad
  output:
    url: images/BW_e000014_01_20240610214155.jpeg
- text: a girl with a flower crown
  output:
    url: images/BW_e000014_00_20240610214140.jpeg
- text: a girl with blonde-brown hair and big round glasses wearing a whit tank top
  output:
    url: images/ComfyUI_01003_.jpeg
- text: girl,neck tuft,white hair,sheep horns,blue eyes
  output:
    url: images/ComfyUI_01023_.jpeg
base_model: stabilityai/stable-diffusion-xl-base-1.0
instance_prompt: null
license: creativeml-openrail-m
---
# B&amp;W Manga Block

<Gallery />

## Model description 

This model makes super bold line portrait illustrations. Best in monochrome with simple prompts.




## Download model

Weights for this model are available in Safetensors format.

Model release is for research purposes only. For commercial use, please contact me directly.

[Download](/alvdansen/BandW-Manga/tree/main) them in the Files & versions tab.
