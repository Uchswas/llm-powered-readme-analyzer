---
tags:
- Safetensors
- Text-to-Image
---
Same as the original [Pony Diffusion V6 XL Turbo DPO](https://civitai.com/models/257749?modelVersionId=298112) but in diffusers version