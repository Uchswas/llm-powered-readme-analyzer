---
license: other
---
Just an easy to download copy of https://huggingface.co/TheBloke/wizardLM-7B-GPTQ/tree/main