---
license: apache-2.0
language:
- en
---
This is a model page to discuss Gemini. Head to https://huggingface.co/clem/gemini/discussions for conversations