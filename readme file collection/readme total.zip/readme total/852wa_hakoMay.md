SD2.1 finetuning model

model HakoMay A/B/C/D/Boy .safetensors


embeddings Mayng.safetensors + Mayng.yaml


License
WD 1.5 is released under the Fair AI Public License 1.0-SD (https://freedevproject.org/faipl-1.0-sd/). If any derivative of this model is made, please share your changes accordingly. Special thanks to ronsor/undeleted (https://undeleted.ronsor.com/) for help with the license.