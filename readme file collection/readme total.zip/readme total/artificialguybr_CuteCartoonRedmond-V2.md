---
license: creativeml-openrail-m
tags:
- text-to-image
- stable-diffusion
- lora
- diffusers
base_model: stabilityai/stable-diffusion-xl-base-1.0
instance_prompt: CuteCartoonAF, Cute Cartoon
widget:
  - text: CuteCartoonAF, Cute Cartoon
---
# CuteCartoon.Redmond V2
![row01](00418-1769284661.png)

CuteCartoon.Redmond is here!
Test all my Lora here: https://huggingface.co/spaces/artificialguybr/artificialguybr-demo-lora

Introducing CuteCartoon.Redmond, the ultimate LORA for creating funny cute images of characters!

I'm grateful for the GPU time from Redmond.AI that allowed me to make this LORA! If you need GPU, then you need the great services from Redmond.AI.

It is based on SD XL 1.0 and fine-tuned on a large dataset.

The LORA has a high capacity to generate funny cute images of characters!

The tag for the model:CuteCartoonAF, Cute Cartoon

I really hope you like the LORA and use it.

If you like the model and think it's worth it, you can make a donation to my Patreon or Ko-fi.

Patreon:

https://www.patreon.com/user?u=81570187

Ko-fi:https://ko-fi.com/artificialguybr

BuyMeACoffe:https://www.buymeacoffee.com/jvkape

Follow me in my twitter to know before all about new models:

https://twitter.com/artificialguybr/