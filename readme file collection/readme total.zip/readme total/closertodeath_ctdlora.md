---
license: other
---
for the style loras use "mksks style" at the beginning of your prompt

all character loras have the "sksname gender" token, while styles are usually the plain names

## License

You are free to:
1. Share — copy and redistribute the material in any medium or format
2. Adapt — remix, transform, and build upon the material, as long as you freely share the changes
   
Under the following terms: 
1. You cannot use the model to deliberately produce nor share illegal or harmful outputs or content
2. Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
3. You may not use the material for commercial purposes, whether it be as a service, sold as is or merged into other material.
4. If you grant access to a modified version of the model available to users over a network, you must make your modified model available to those users immediately.